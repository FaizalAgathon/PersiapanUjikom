<?php
require "connection.php";
require('fpdf/fpdf.php');

class PDF extends FPDF
{
  // Better table
  function ImprovedTable($header, $data)
  {
    // Column widths
    $w = array(40, 75, 75);
    // Header
    for ($i = 0; $i < count($header); $i++)
      $this->Cell($w[$i], 7, $header[$i], 1, 0, 'C');
    $this->Ln();
    // Data
    $baris = 1;
    foreach ($data as $row) {
      $this->Cell($w[0], 8, $row['id'], 1, 0, 'C');
      $this->Cell($w[1], 8, $row['name'], 1, 0, 'LR');
      $this->Cell($w[2], 8, $row['score'], 1, 0, 'R');
      $this->Ln();
      $baris++;
      if ($baris == 30) {
        $this->Cell(190, 10, "DATA KIS", 1, 1, 'C');
        $this->Ln();
        for ($i = 0; $i < count($header); $i++)
          $this->Cell($w[$i], 7, $header[$i], 1, 0, 'C');
        $this->Ln();
      }
    }
    // Closing line
    $this->Cell(array_sum($w), 0, '', 'T');
  }
}

$pdf = new PDF();
// Column headings
$header = array('id', 'name', 'score');
// Data loading
$data = query("SELECT * FROM students");
$pdf->SetFont('Arial', '', 14);
$pdf->AddPage();
$pdf->Cell(190, 10, "DATA KIS", 1, 1, 'C');
$pdf->Ln();
$pdf->ImprovedTable($header, $data);
$pdf->SetTitle("Daftar Pengguna");
$pdf->PageNo();
$pdf->Output();
